from enum import Enum

class ClassificationStrategy(Enum):
    CONTENT_BASED = 1
    COLABORATIVE_FILTERING = 2