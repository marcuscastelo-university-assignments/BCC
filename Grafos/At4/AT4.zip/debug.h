#pragma once

#include <stdio.h>

/// TODO: CHANGE BEFORE RUN.CODES
#define DEBUG 1
////////////////////////////////
#define DP(...) if (DEBUG) { fprintf(stderr, __VA_ARGS__); }